package lesson1;

public interface Identity {
    String getName();
    int getMaxLength();
    int getMaxHeight();

    void run();

    void jump();
}
