package lesson1;

public interface ObstacleRace {
    String getName();
    boolean isCheck(Identity gamer);
}
